package com.example.prg1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText username;
    EditText password;
     Button login;
    String name="Admin";
    String ps="1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
              public void onClick(View view)
            {

                String inpName=username.getText().toString();
                String inPassword=password.getText().toString();
                if (inpName.isEmpty() || inPassword.isEmpty()) {
                    Toast.makeText(MainActivity.this, "fields are empty", Toast.LENGTH_SHORT).show();
                } else {
                    if (inpName.equals(name) && inPassword.equals(ps)) {
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Incorrect Username or Password ", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
    }
}



