package com.example.calcu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText var1,var2;
    Button button1,button2,button3,button4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        var1=findViewById(R.id.var1);
        var2=findViewById(R.id.var2);
        button1=(Button) findViewById(R.id.button1);
        button2=(Button) findViewById(R.id.button2);
        button3=(Button) findViewById(R.id.button3);
        button4=(Button) findViewById(R.id.button4);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int varr1=Integer.parseInt(var1.getText().toString());
                int varr2=Integer.parseInt(var2.getText().toString());
                int a=varr1+varr2;
                Toast.makeText(MainActivity.this, "Sum of integers is:" +a, Toast.LENGTH_LONG).show();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int varr1=Integer.parseInt(var1.getText().toString());
                int varr2=Integer.parseInt(var2.getText().toString());
                int b=varr1-varr2;
                Toast.makeText(MainActivity.this,"Difference of integers is: "+b,Toast.LENGTH_LONG).show();
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int varr1=Integer.parseInt(var1.getText().toString());
                int varr2=Integer.parseInt(var2.getText().toString());
                int c=varr1*varr2;
                Toast.makeText(MainActivity.this, "Product of integers is: "+c, Toast.LENGTH_LONG).show();
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int varr1=Integer.parseInt(var1.getText().toString());
                int varr2=Integer.parseInt(var2.getText().toString());
                int d=varr1/varr2;
                Toast.makeText(MainActivity.this, "Remainder of integers is:"+d, Toast.LENGTH_LONG).show();
            }
        });
    }
}
